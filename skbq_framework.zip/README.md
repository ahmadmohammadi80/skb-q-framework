
# SKB-Q Framework

This repository contains the official implementation of **SKB-Q (Structure-Knowledge-Based Quantization)** for mixed-precision post-training quantization of LLMs.

## Abstract
We propose a graph-structured constrained optimization framework that extracts structural features (operator depth, type, and layer position) alongside activation-weighted salience scores to solve a Lagrangian-relaxation bit allocation problem.

## Results
- **OPT-125M**: Structure-Only achieves PPL 95.86 at 4.49 bits (matches paper claim PPL 100.89 at 4.46 bits).
- **OPT-1.3B**: Salience-Only achieves PPL 43.14 at 4.50 bits, confirming that activation salience becomes more relevant at larger scales.

## How to Run in Google Colab
1. Open Google Colab with GPU (T4 recommended).
2. Copy the content of `run_skbq.py` into a cell and run it.
3. To test OPT-1.3B, change `MODEL_NAME = "facebook/opt-1.3b"` and `NUM_LAYERS = 24`.

## Files
- `run_skbq.py`: Main script.
- `results_opt_125m.json`: Output results for OPT-125M.
- `results_opt_1.3b.json`: Output results for OPT-1.3B.

## Citation
Please cite our paper if you use this code.
